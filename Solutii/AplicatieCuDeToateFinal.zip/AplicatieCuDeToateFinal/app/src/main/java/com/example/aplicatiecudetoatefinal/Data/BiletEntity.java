package com.example.aplicatiecudetoatefinal.Data;

import androidx.room.ColumnInfo;
import androidx.room.Entity;
import androidx.room.PrimaryKey;
import androidx.room.TypeConverter;
import androidx.room.TypeConverters;

import com.example.aplicatiecudetoatefinal.Utils.TipBilet;

import java.util.Date;

@Entity(tableName = "bilete")
public  class BiletEntity {
    @PrimaryKey(autoGenerate = true)
    Integer id;

    @ColumnInfo(name="nume")
    String nume;

    @ColumnInfo(name = "pret")
    Float pret;

    @ColumnInfo(name = "optiuniCazare")
    String optiuniCazare;

    @ColumnInfo(name = "dataCumparare")
    Date dataCumparare;

    @ColumnInfo(name = "tipBilet")
    TipBilet tipBilet;

    @Override
    public String toString() {
        return "BiletEntity{" +
                "id=" + id +
                ", nume='" + nume + '\'' +
                ", pret=" + pret +
                ", optiuniCazare='" + optiuniCazare + '\'' +
                ", dataCumparare=" + dataCumparare +
                ", tipBilet=" + tipBilet +
                '}';
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getNume() {
        return nume;
    }

    public void setNume(String nume) {
        this.nume = nume;
    }

    public Float getPret() {
        return pret;
    }

    public void setPret(Float pret) {
        this.pret = pret;
    }

    public String getOptiuniCazare() {
        return optiuniCazare;
    }

    public void setOptiuniCazare(String optiuniCazare) {
        this.optiuniCazare = optiuniCazare;
    }

    public Date getDataCumparare() {
        return dataCumparare;
    }

    public void setDataCumparare(Date dataCumparare) {
        this.dataCumparare = dataCumparare;
    }

    public TipBilet getTipBilet() {
        return tipBilet;
    }

    public void setTipBilet(TipBilet tipBilet) {
        this.tipBilet = tipBilet;
    }
}
