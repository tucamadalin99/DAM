package com.example.aplicatiecudetoatefinal;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;

import com.example.aplicatiecudetoatefinal.Activities.MainActivity;
import com.example.aplicatiecudetoatefinal.Classes.BiletFestival;

import java.util.ArrayList;

public class ListaBileteActivity extends AppCompatActivity {
    public static final int EDIT_REQ_CODE = 21;

    private Intent intent;

    private ArrayList<BiletFestival> bilete = new ArrayList<>();

    private BiletAdapter biletAdapter;

    private ListView lv_bilete;

    private int index;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_lista_bilete);
        lv_bilete = findViewById(R.id.lv_bilete);
        intent = getIntent();
        Bundle extras = intent.getExtras();
        bilete = extras.getParcelableArrayList(MainActivity.BILETE_KEY);
        Log.v("list", bilete.toString());
        biletAdapter = new BiletAdapter(getApplicationContext(), R.layout.lv_custom_item, bilete, getLayoutInflater());
        lv_bilete.setAdapter(biletAdapter);
        biletAdapter.notifyDataSetChanged();
        lv_bilete.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Intent intent = new Intent(getApplicationContext(), AdaugareBiletActivity.class);
                BiletFestival biletEditare = bilete.get(position);
                index = position;
                Bundle bundle = new Bundle();
                bundle.putParcelable(AdaugareBiletActivity.BILET_KEY, biletEditare);
                intent.putExtras(bundle);
                setResult(RESULT_OK, intent);
                startActivityForResult(intent, EDIT_REQ_CODE);
            }
        });
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == EDIT_REQ_CODE
                && resultCode == RESULT_OK && data != null) {
            if(AdaugareBiletActivity.isDelete) {
                bilete.remove(index);
            }
            else {
                BiletFestival biletEditat=data.getParcelableExtra(AdaugareBiletActivity.BILET_KEY);
                BiletFestival biletEditatLv=bilete.get(index);
                biletEditatLv.setNumeFestival(biletEditat.getNumeFestival());
                biletEditatLv.setPret(biletEditat.getPret());
                biletEditatLv.setDataCumparare(biletEditat.getDataCumparare());
                biletEditatLv.setOptiuniCazare(biletEditat.getOptiuniCazare());
                biletEditatLv.setTipBilet(biletEditat.getTipBilet());
            }

            BiletAdapter adapter= (BiletAdapter) lv_bilete.getAdapter();
            adapter.notifyDataSetChanged();

        }
    }
}