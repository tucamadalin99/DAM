package com.example.aplicatiecudetoatefinal.GettingData;

import android.util.Log;

import com.example.aplicatiecudetoatefinal.Classes.BiletFestival;
import com.example.aplicatiecudetoatefinal.Converters.Converters;
import com.example.aplicatiecudetoatefinal.Utils.TipBilet;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserException;
import org.xmlpull.v1.XmlPullParserFactory;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;
import java.util.Date;

public class DownloadManager {

    private static DownloadManager instance;
    public DownloadManager() {}

    public static DownloadManager getInstance() {
        if(instance==null) {
            instance=new DownloadManager();
        }
        return instance;
    }

    public void getData(final IBiletResponse listener) {
        new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    URL url=new URL("https://api.mocki.io/v1/50defa50");
                    HttpURLConnection connection= (HttpURLConnection) url.openConnection();
                    InputStream stream=connection.getInputStream();
                    InputStreamReader reader=new InputStreamReader(stream);
                    BufferedReader bufferedReader=new BufferedReader(reader);
                    StringBuilder stringBuilder=new StringBuilder();
                    String line="";
                    while ((line=bufferedReader.readLine())!=null) {
                        stringBuilder.append(line);
                    }
                    bufferedReader.close();
                    reader.close();
                    stream.close();
                    listener.onSuccess(parseBiletJson(stringBuilder.toString()));
                } catch (MalformedURLException e) {
                    e.printStackTrace();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }).start();
    }

    public void getDataXML(final IBiletResponse listener) {
        new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    XmlPullParserFactory xmlPullParserFactory= XmlPullParserFactory.newInstance();
                    XmlPullParser parser=xmlPullParserFactory.newPullParser();
                    URL url=new URL("https://pastebin.com/raw/5DJRgufS");
                    HttpURLConnection connection = (HttpURLConnection) url.openConnection();
                    InputStream is = connection.getInputStream();
                    parser.setFeature(XmlPullParser.FEATURE_PROCESS_NAMESPACES, false);
                    parser.setInput(is, null);
                    listener.onSuccess(parseSesizareXML(parser));
                } catch (XmlPullParserException | MalformedURLException e) {
                    e.printStackTrace();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }).start();
    }

    public void getDataCSV(final IBiletResponse listener) {
        new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    URL url=new URL("https://pastebin.com/raw/25fhA0d7");
                    HttpURLConnection connection= (HttpURLConnection) url.openConnection();
                    InputStream stream=connection.getInputStream();
                    InputStreamReader reader=new InputStreamReader(stream);
                    BufferedReader bufferedReader=new BufferedReader(reader);
                    StringBuilder stringBuilder=new StringBuilder();
                    String line="";
                    while ((line=bufferedReader.readLine())!=null) {

                        stringBuilder.append(line);
                    }
                    bufferedReader.close();
                    reader.close();
                    stream.close();
                    listener.onSuccess(parseBiletCSV(stringBuilder.toString()));
                } catch (MalformedURLException e) {
                    e.printStackTrace();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }).start();
    }

    private ArrayList<BiletFestival> parseBiletCSV(String toString) {
        ArrayList<BiletFestival> bilete=new ArrayList<>();
        String[] strings=toString.split(",");
        for(int i=0;i<strings.length;i+=5) {
            String nume=strings[i];
            Float pret=Float.parseFloat(strings[i+1]);
            TipBilet tipBilet=new Converters().EnumfromString(strings[i+2]);
            String[] optiuniCazare=strings[i+3].split(";");
            Date dataCumparare=new Converters().DatefromString(strings[i+4]);
            bilete.add(new BiletFestival(nume,pret,optiuniCazare,dataCumparare,tipBilet));
        }
        return bilete;
    }

    private ArrayList<BiletFestival> parseSesizareXML(XmlPullParser parser) throws IOException, XmlPullParserException {
        ArrayList<BiletFestival> bilete=new ArrayList<>();
        int eventType=0;
        try {
            eventType=parser.getEventType();
        } catch (XmlPullParserException e) {
            e.printStackTrace();
        }
        BiletFestival biletCurent=null;
        while(eventType!=XmlPullParser.END_DOCUMENT) {
            String elName = null;
            switch (eventType) {
                case XmlPullParser.START_TAG:
                    elName=parser.getName();
                    if(elName.equals("bilet")){
                        biletCurent=new BiletFestival();
                        bilete.add(biletCurent);
                    }
                    else if(biletCurent!=null){
                        if(elName.equals("nume")) {
                            biletCurent.setNumeFestival(parser.nextText());
                        }
                        else if(elName.equals("pret")) {
                            biletCurent.setPret(Float.parseFloat(parser.nextText()));
                        }
                        else if(elName.equals("tipBilet")) {
                            biletCurent.setTipBilet(new Converters().EnumfromString(parser.nextText()));
                        }
                        else if(elName.equals("dataCumparare")) {
                            biletCurent.setDataCumparare(new Converters().DatefromString(parser.nextText()));
                        }
                        else if(elName.equals("optiuniCazare")){
                            biletCurent.setOptiuniCazare(parser.nextText().split(","));
                        }
                    }
                    break;
            }
            eventType=parser.next();
        }
        return bilete;
    }

    private ArrayList<BiletFestival> parseBiletJson(String result) {
        ArrayList<BiletFestival> bilete=new ArrayList<>();
        try{
            JSONObject resultJson=new JSONObject(result);
            JSONArray sesizariJson=resultJson.getJSONArray("bilete");
            for(int i=0;i<sesizariJson.length();i++) {
                JSONObject currentObj=sesizariJson.getJSONObject(i);
                String nume=currentObj.getString("nume");
                Float pret=Float.parseFloat(currentObj.getString("pret"));
                TipBilet tipBilet=new Converters().EnumfromString(currentObj.getString("tipBilet"));
                Date dataCumparare=new Converters().DatefromString(currentObj.getString("dataCumparare"));
                String[] optiuniCazare=currentObj.getString("optiuniCazare").split(",");
                bilete.add(new BiletFestival(nume,pret,optiuniCazare,dataCumparare,tipBilet));

            }
        } catch (JSONException e) {
            e.printStackTrace();
        }
        return bilete;
    }
}
