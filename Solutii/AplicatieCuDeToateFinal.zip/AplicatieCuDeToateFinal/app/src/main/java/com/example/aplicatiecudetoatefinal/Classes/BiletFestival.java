package com.example.aplicatiecudetoatefinal.Classes;

import android.os.Parcel;
import android.os.Parcelable;

import com.example.aplicatiecudetoatefinal.Converters.Converters;
import com.example.aplicatiecudetoatefinal.Utils.TipBilet;

import java.util.Arrays;
import java.util.Date;

public class BiletFestival implements Parcelable {
    private String numeFestival;
    private float pret;
    private String[] optiuniCazare;
    private Date dataCumparare;
    private TipBilet tipBilet;

    public BiletFestival(){}

    public BiletFestival(String numeFestival, float pret, String[] optiuniCazare, Date dataCumparare, TipBilet tipBilet) {
        this.numeFestival = numeFestival;
        this.pret = pret;
        this.optiuniCazare = optiuniCazare;
        this.dataCumparare = dataCumparare;
        this.tipBilet = tipBilet;
    }

    protected BiletFestival(Parcel in) {
        numeFestival = in.readString();
        pret = in.readFloat();
        optiuniCazare = in.createStringArray();
        dataCumparare=(new Converters().DatefromString(in.readString()));
        tipBilet=(new Converters().EnumfromString(in.readString()));
    }

    public static final Creator<BiletFestival> CREATOR = new Creator<BiletFestival>() {
        @Override
        public BiletFestival createFromParcel(Parcel in) {
            return new BiletFestival(in);
        }

        @Override
        public BiletFestival[] newArray(int size) {
            return new BiletFestival[size];
        }
    };

    public String getNumeFestival() {
        return numeFestival;
    }

    public void setNumeFestival(String numeFestival) {
        this.numeFestival = numeFestival;
    }

    public float getPret() {
        return pret;
    }

    public void setPret(float pret) {
        this.pret = pret;
    }

    public String[] getOptiuniCazare() {
        return optiuniCazare;
    }

    public void setOptiuniCazare(String[] optiuniCazare) {
        this.optiuniCazare = optiuniCazare;
    }

    public Date getDataCumparare() {
        return dataCumparare;
    }

    public void setDataCumparare(Date dataCumparare) {
        this.dataCumparare = dataCumparare;
    }

    public TipBilet getTipBilet() {
        return tipBilet;
    }

    public void setTipBilet(TipBilet tipBilet) {
        this.tipBilet = tipBilet;
    }

    @Override
    public String toString() {
        return "BiletFestival{" +
                "numeFestival='" + numeFestival + '\'' +
                ", pret=" + pret +
                ", optiuniCazare=" + Arrays.toString(optiuniCazare) +
                ", dataCumparare=" + dataCumparare +
                ", tipBilet=" + tipBilet +
                '}';
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(numeFestival);
        dest.writeFloat(pret);
        dest.writeStringArray(optiuniCazare);
        dest.writeString(new Converters().DatetoString(dataCumparare));
        dest.writeString(new Converters().StringToEnum(tipBilet));
    }
}
