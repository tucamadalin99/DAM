package com.example.aplicatiecudetoatefinal;

import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.RadioGroup;
import android.widget.Toast;

import com.example.aplicatiecudetoatefinal.Classes.BiletFestival;
import com.example.aplicatiecudetoatefinal.Converters.Converters;
import com.example.aplicatiecudetoatefinal.Data.BiletBD;
import com.example.aplicatiecudetoatefinal.Data.BiletDao;
import com.example.aplicatiecudetoatefinal.Data.BiletEntity;
import com.example.aplicatiecudetoatefinal.Utils.TipBilet;
import com.google.android.material.textfield.TextInputEditText;

import java.util.Date;
import java.util.List;

public class AdaugareBiletActivity extends AppCompatActivity {

    private TextInputEditText nume;
    private TextInputEditText pret;
    private TextInputEditText optiuniCazare;
    private TextInputEditText data;
    private RadioGroup rgTip;

    private Button btnAdd;
    private Button btnDelete;

    private Intent intent;

    private boolean isEdit=false;
    public static boolean isDelete=false;

    public static final String BILET_KEY="bilet_key";

    @RequiresApi(api = Build.VERSION_CODES.O)
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_adaugare_bilet);
        initComponents();
        intent=getIntent();
        btnAdd.setOnClickListener(addBilet());
        btnDelete.setOnClickListener(delteBilet());
        isDelete=false;
        populateForm();
    }

    private View.OnClickListener delteBilet() {
      return new View.OnClickListener() {
          @Override
          public void onClick(View v) {
              isDelete=true;
              if(validate()) {
                  //Db init
                  final BiletEntity biletEntity=new BiletEntity();
                  biletEntity.setNume(nume.getText().toString());
                  biletEntity.setPret(Float.parseFloat(pret.getText().toString()));
                  biletEntity.setOptiuniCazare(optiuniCazare.getText().toString());
                  biletEntity.setDataCumparare(new Converters().DatefromString(data.getText().toString()));
                  TipBilet tipBiletB;
                  switch (rgTip.getCheckedRadioButtonId()) {
                      case R.id.rb_normal:
                          tipBiletB=TipBilet.normal;
                          break;
                      case R.id.rb_extra:
                          tipBiletB=TipBilet.extra;
                          break;
                      case R.id.rb_vip:
                          tipBiletB=TipBilet.vip;
                          break;
                      default:
                          throw new IllegalStateException("Unexpected value: " + rgTip.getCheckedRadioButtonId());
                  }
                  biletEntity.setTipBilet(tipBiletB);
                  Log.v("entitiy:",biletEntity.toString());
                  BiletBD biletBD=BiletBD.getDatabase(getApplicationContext());
                  final BiletDao biletDao=biletBD.biletDao();
                  new Thread(new Runnable() {
                      @Override
                      public void run() {
                          biletDao.deleteBilet(biletEntity.getNume());
                          final List<BiletEntity> biletEntityList = biletDao.getAllBilete();
                          runOnUiThread(new Runnable() {
                              @Override
                              public void run() {
                                  for(BiletEntity bilet:biletEntityList) {
                                      Log.v("id:",bilet.getId().toString());
                                      Log.v("delete:",bilet.toString());
                                  }
                                  Toast.makeText(AdaugareBiletActivity.this, "Deleted from BD", Toast.LENGTH_SHORT).show();
                              }
                          });
                      }
                  }).start();


                  BiletFestival biletFestival=buildBilet();
                  Bundle bundle=new Bundle();
                  bundle.putParcelable(BILET_KEY,biletFestival);
                  intent.putExtras(bundle);
                  setResult(RESULT_OK,intent);
                  finish();
              }
          }
      } ;
    };

    @RequiresApi(api = Build.VERSION_CODES.O)
    private void populateForm() {
        BiletFestival biletEditare=intent.getParcelableExtra(BILET_KEY);
        if(biletEditare!=null) {
            Log.v("EDT:",biletEditare.toString());
            isEdit=true;
            nume.setText(biletEditare.getNumeFestival().toString());
            pret.setText(String.valueOf(biletEditare.getPret()));
            String[] optiuni=biletEditare.getOptiuniCazare();
            String optiuniS=String.join(",",optiuni);
            optiuniCazare.setText(optiuniS);
            data.setText(new Converters().DatetoString(biletEditare.getDataCumparare()));
            switch(biletEditare.getTipBilet().name()) {
                case "extra":
                    rgTip.check(R.id.rb_extra);
                    break;
                case "vip":
                    rgTip.check(R.id.rb_vip);
                    break;
            }
            btnAdd.setText("Editeaza");
        }

    }

    private View.OnClickListener addBilet() {
        return new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if(validate()) {
                    //Db init
                    final BiletEntity biletEntity=new BiletEntity();
                    biletEntity.setNume(nume.getText().toString());
                    biletEntity.setPret(Float.parseFloat(pret.getText().toString()));
                    biletEntity.setOptiuniCazare(optiuniCazare.getText().toString());
                    biletEntity.setDataCumparare(new Converters().DatefromString(data.getText().toString()));
                    TipBilet tipBiletB;
                    switch (rgTip.getCheckedRadioButtonId()) {
                        case R.id.rb_normal:
                            tipBiletB=TipBilet.normal;
                            break;
                        case R.id.rb_extra:
                            tipBiletB=TipBilet.extra;
                            break;
                        case R.id.rb_vip:
                            tipBiletB=TipBilet.vip;
                            break;
                        default:
                            throw new IllegalStateException("Unexpected value: " + rgTip.getCheckedRadioButtonId());
                    }
                    biletEntity.setTipBilet(tipBiletB);
                    Log.v("entitiy:",biletEntity.toString());
                    BiletBD biletBD=BiletBD.getDatabase(getApplicationContext());
                    final BiletDao biletDao=biletBD.biletDao();
                    new Thread(new Runnable() {
                        @Override
                        public void run() {
                            if(isEdit) {
                                biletDao.updateBilet(biletEntity);
                                runOnUiThread(new Runnable() {
                                    @Override
                                    public void run() {
                                        Toast.makeText(AdaugareBiletActivity.this, "Updated in BD!", Toast.LENGTH_SHORT).show();
                                    }
                                });
                            }
                            else {
                                biletDao.addBilet(biletEntity);
                                Log.v("biletBD:",biletEntity.toString());
                                runOnUiThread(new Runnable() {
                                    @Override
                                    public void run() {
                                        Toast.makeText(AdaugareBiletActivity.this, "Added to db!", Toast.LENGTH_SHORT).show();
                                    }
                                });
                            }

                        }
                    }).start();

                    //Normal send
                    BiletFestival biletFestival=buildBilet();
                    Bundle bundle=new Bundle();
                    bundle.putParcelable(BILET_KEY,biletFestival);
                    intent.putExtras(bundle);
                    setResult(RESULT_OK,intent);
                    finish();
                }
            }
        };

    }

    private BiletFestival buildBilet() {
        String numeB=nume.getText().toString();
        Float pretB=Float.parseFloat(pret.getText().toString());
        String[] optiuniCazareB=optiuniCazare.getText().toString().split(",");
        Date dataB=new Converters().DatefromString(data.getText().toString());
        TipBilet tipBiletB=TipBilet.normal;
        switch (rgTip.getCheckedRadioButtonId()) {
            case R.id.rb_extra:
                tipBiletB=TipBilet.extra;
                break;
            case R.id.rb_vip:
                tipBiletB=TipBilet.vip;
                break;
        }
        return new BiletFestival(numeB,pretB,optiuniCazareB,dataB,tipBiletB);
    }

    private boolean validate() {
        if(nume.getText().toString().isEmpty()) {
            Toast.makeText(this, "Nume invalid", Toast.LENGTH_SHORT).show();
            return false;
        }
        if(pret.getText().toString().isEmpty()) {
            Toast.makeText(this, "Pret invalid", Toast.LENGTH_SHORT).show();
            return false;
        }
        if(!optiuniCazare.getText().toString().contains(",")) {
            Toast.makeText(this, "Optiuni invalide", Toast.LENGTH_SHORT).show();
            return false;
        }

        if(data.getText().toString().isEmpty()) {
            Toast.makeText(this, "Data invalida", Toast.LENGTH_SHORT).show();
            return false;
        }


        return true;
    }

    private void initComponents() {
        nume=findViewById(R.id.tiet_nume);
        pret=findViewById(R.id.tiet_pret);
        optiuniCazare=findViewById(R.id.tiet_optiuni_cazare);
        data=findViewById(R.id.tiet_data);
        rgTip=findViewById(R.id.rg_tipBilet);

        btnAdd=findViewById(R.id.btn_add);
        btnDelete=findViewById(R.id.btn_delete);
    }
}