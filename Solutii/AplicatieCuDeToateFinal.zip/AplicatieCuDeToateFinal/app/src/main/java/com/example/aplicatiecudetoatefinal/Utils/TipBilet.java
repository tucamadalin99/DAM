package com.example.aplicatiecudetoatefinal.Utils;

public enum TipBilet {
    normal(0), extra(1), vip(2);
    public int value;
    TipBilet(int value) {
        this.value=value;
    }
}
