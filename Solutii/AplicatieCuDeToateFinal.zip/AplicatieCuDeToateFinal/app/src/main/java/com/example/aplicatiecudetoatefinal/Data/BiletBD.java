package com.example.aplicatiecudetoatefinal.Data;

import android.content.Context;

import androidx.room.Database;
import androidx.room.Room;
import androidx.room.RoomDatabase;
import androidx.room.TypeConverters;

import com.example.aplicatiecudetoatefinal.Converters.Converters;


@Database(entities = {BiletEntity.class}, version = 1, exportSchema = false)
@TypeConverters({Converters.class})
public abstract class BiletBD extends RoomDatabase {
    private static final String dbName="bilete";
    private static BiletBD biletBD;

    public static  synchronized BiletBD getDatabase(Context context) {
        if(biletBD==null) {
            biletBD= Room.databaseBuilder(context,BiletBD.class,dbName)
//                    //ASTA DOAR PT GRAFIC
                    .allowMainThreadQueries()
                    .fallbackToDestructiveMigration()
                    .build();
        }
        return biletBD;
    }

    public abstract BiletDao biletDao();
}
