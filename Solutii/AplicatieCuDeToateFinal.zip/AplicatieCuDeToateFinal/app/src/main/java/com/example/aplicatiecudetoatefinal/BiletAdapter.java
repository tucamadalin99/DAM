package com.example.aplicatiecudetoatefinal;

import android.content.Context;
import android.os.Build;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.annotation.RequiresApi;

import com.example.aplicatiecudetoatefinal.Classes.BiletFestival;
import com.example.aplicatiecudetoatefinal.Converters.Converters;

import java.util.List;

public class BiletAdapter extends ArrayAdapter<BiletFestival> {
    private Context context;
    private List<BiletFestival> bilete;
    private LayoutInflater inflater;
    private int resource;

    public BiletAdapter(@NonNull Context context, int resource, @NonNull List<BiletFestival> objects, LayoutInflater inflater) {
        super(context, resource, objects);
        this.context=context;
        this.bilete=objects;
        this.inflater=inflater;
        this.resource=resource;
    }


    @RequiresApi(api = Build.VERSION_CODES.O)
    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        View view=inflater.inflate(resource,parent,false);
        BiletFestival bilet=bilete.get(position);
        if(bilet !=null) {
            TextView tvnume=view.findViewById(R.id.lv_item_nume);
            tvnume.setText(bilet.getNumeFestival());
            TextView tvPret=view.findViewById(R.id.lv_item_pret);
            tvPret.setText(String.valueOf(bilet.getPret()));
            TextView tvOptiuni=view.findViewById(R.id.lv_item_optiuni);
            String[] optiuni=bilet.getOptiuniCazare();
            String optiuniS=String.join(",",optiuni);
            tvOptiuni.setText(optiuniS);
            TextView tvData=view.findViewById(R.id.lv_item_data);
            tvData.setText(new Converters().DatetoString(bilet.getDataCumparare()));
            TextView tvTip=view.findViewById(R.id.lv_item_tip);
            tvTip.setText(new Converters().StringToEnum(bilet.getTipBilet()));
        }
        return view;
    }
}
