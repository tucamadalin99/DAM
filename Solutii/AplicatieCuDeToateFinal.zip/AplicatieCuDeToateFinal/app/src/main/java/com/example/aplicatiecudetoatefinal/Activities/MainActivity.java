package com.example.aplicatiecudetoatefinal.Activities;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.os.Parcelable;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.Toast;

import com.example.aplicatiecudetoatefinal.AdaugareBiletActivity;
import com.example.aplicatiecudetoatefinal.BiletAdapter;
import com.example.aplicatiecudetoatefinal.Classes.BiletFestival;
import com.example.aplicatiecudetoatefinal.Data.BiletBD;
import com.example.aplicatiecudetoatefinal.Data.BiletDao;
import com.example.aplicatiecudetoatefinal.Data.BiletEntity;
import com.example.aplicatiecudetoatefinal.GettingData.DownloadManager;
import com.example.aplicatiecudetoatefinal.GettingData.IBiletResponse;
import com.example.aplicatiecudetoatefinal.ListaBileteActivity;
import com.example.aplicatiecudetoatefinal.PreluareCSV;
import com.example.aplicatiecudetoatefinal.PreluareJSON;
import com.example.aplicatiecudetoatefinal.PreluareXML;
import com.example.aplicatiecudetoatefinal.R;
import com.example.aplicatiecudetoatefinal.Raport;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class MainActivity extends AppCompatActivity {
    //Codes
    public static final Integer ADD_REQ=1;
    public static final String BILETE_KEY="bilete_key";

    //Shared preferences init
    public static final String SHARED_PREFS="sharedPrefs";
    public static final Date DATE=new Date(System.currentTimeMillis());
    public static final String DATE_KEY="Date_key";
    SharedPreferences sharedPreferences;


    private ArrayList<BiletFestival> bilete=new ArrayList<>();



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //Shared prefs call
        long date=DATE.getTime();
        sharedPreferences=getSharedPreferences(SHARED_PREFS,MODE_PRIVATE);
        SharedPreferences.Editor editor=sharedPreferences.edit();
        editor.putLong(DATE_KEY,date);
        editor.apply();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        super.onCreateOptionsMenu(menu);
        getMenuInflater().inflate(R.menu.main_menu,menu);
        return true;
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == ADD_REQ
                && resultCode == RESULT_OK && data != null) {
            Bundle extras=data.getExtras();
            BiletFestival bilet=extras.getParcelable(AdaugareBiletActivity.BILET_KEY);
            bilete.add(bilet);
            Log.v("mainact",bilet.toString());
        }

        BiletBD biletBD=BiletBD.getDatabase(getApplicationContext());
        final BiletDao biletDao=biletBD.biletDao();
        new Thread(new Runnable() {
            @Override
            public void run() {
                final List<BiletEntity> biletEntityList=biletDao.getAllBilete();
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        for(BiletEntity bilet: biletEntityList) {
                            Log.v("bilet",bilet.toString());
                        }
                    }
                });
            }
        }).start();
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        super.onOptionsItemSelected(item);

        switch (item.getItemId()) {
            case R.id.adaugare_bilet:
                Intent intent=new Intent(getApplicationContext(), AdaugareBiletActivity.class);
                startActivityForResult(intent,ADD_REQ);
                break;
            case R.id.lista_bilete:
                Bundle bundle=new Bundle();
                bundle.putParcelableArrayList(BILETE_KEY, bilete);
                intent=new Intent(getApplicationContext(), ListaBileteActivity.class);
                intent.putExtras(bundle);
                startActivity(intent);
                setResult(RESULT_OK,intent);
                break;
            case R.id.preluare_json:
                getJsonData();
                Toast.makeText(this, "Parsed data fomr JSON", Toast.LENGTH_SHORT).show();
//                intent=new Intent(getApplicationContext(), PreluareJSON.class);
//                startActivity(intent);
                break;
            case R.id.preluare_xml:
                getXMLData();
                Toast.makeText(this, "Parsed data from XML", Toast.LENGTH_SHORT).show();
//                intent=new Intent(getApplicationContext(), PreluareXML.class);
//                startActivity(intent);
                break;
            case R.id.preluare_csv:
//                intent=new Intent(getApplicationContext(), PreluareCSV.class);
//                startActivity(intent);
                getCSVData();
                Toast.makeText(this, "Parsed data from CSV", Toast.LENGTH_SHORT).show();
                break;
            case R.id.grafic_piechart:
                intent=new Intent(getApplicationContext(), Raport.class);
                startActivity(intent);
                break;
            case R.id.grafic_barchart:
                break;
            case R.id.grafic_despre:
                long date=sharedPreferences.getLong(DATE_KEY,0);
                Date data=new Date(date);
                Toast.makeText(this, getString(R.string.autor) + data, Toast.LENGTH_SHORT).show();
                break;
        }
        return true;
    }

    private void getCSVData() {
        DownloadManager.getInstance().getDataCSV(new IBiletResponse() {
            @Override
            public void onSuccess(final ArrayList<BiletFestival> success) {
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                       bilete.addAll(success);
                    }
                });
            }

            @Override
            public void onFailure(int errCode, Throwable err) {

            }
        });
    }

    private void getXMLData() {
        DownloadManager.getInstance().getDataXML(new IBiletResponse() {
            @Override
            public void onSuccess(final ArrayList<BiletFestival> success) {
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        bilete.addAll(success);
                    }
                });
            }

            @Override
            public void onFailure(int errCode, Throwable err) {

            }
        });
    }

    private void getJsonData() {
        DownloadManager.getInstance().getData(new IBiletResponse() {
            @Override
            public void onSuccess(final ArrayList<BiletFestival> success) {
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
//                        biletAdapter=new BiletAdapter(getApplicationContext(),R.layout.lv_custom_item,success,getLayoutInflater());
//                        lv_preluat.setAdapter(biletAdapter);
                        bilete.addAll(success);
                    }
                });
            }

            @Override
            public void onFailure(int errCode, Throwable err) {
                Log.v("ERR",errCode+err.getLocalizedMessage());
            }
        });
    }
}