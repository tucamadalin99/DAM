package com.example.aplicatiecudetoatefinal.GettingData;

import com.example.aplicatiecudetoatefinal.Classes.BiletFestival;

import java.util.ArrayList;

public interface IBiletResponse {
    void onSuccess(ArrayList<BiletFestival> success);
    //    void onSuccessLib(Library lib);
    void onFailure(int errCode, Throwable err);
}
