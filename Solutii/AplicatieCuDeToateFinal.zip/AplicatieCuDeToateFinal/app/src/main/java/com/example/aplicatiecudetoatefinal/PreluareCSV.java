package com.example.aplicatiecudetoatefinal;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.ListView;
import android.widget.Toast;

import com.example.aplicatiecudetoatefinal.Classes.BiletFestival;
import com.example.aplicatiecudetoatefinal.GettingData.DownloadManager;
import com.example.aplicatiecudetoatefinal.GettingData.IBiletResponse;

import java.util.ArrayList;

public class PreluareCSV extends AppCompatActivity {
    private ListView lv_preluat;
    private BiletAdapter biletAdapter;
    private ArrayList<BiletFestival> bilete=new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_preluare_c_s_v);
        lv_preluat=findViewById(R.id.lv_bilete_csv);
        DownloadManager.getInstance().getDataCSV(new IBiletResponse() {
            @Override
            public void onSuccess(final ArrayList<BiletFestival> success) {
               runOnUiThread(new Runnable() {
                   @Override
                   public void run() {
                       biletAdapter=new BiletAdapter(getApplicationContext(),R.layout.lv_custom_item,success,getLayoutInflater());
                       lv_preluat.setAdapter(biletAdapter);
                       bilete=success;
                   }
               });
            }

            @Override
            public void onFailure(int errCode, Throwable err) {

            }
        });
    }
}