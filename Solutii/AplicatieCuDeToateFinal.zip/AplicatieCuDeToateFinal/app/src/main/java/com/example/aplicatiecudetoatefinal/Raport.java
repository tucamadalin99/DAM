package com.example.aplicatiecudetoatefinal;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.RectF;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.LinearLayout;

import com.example.aplicatiecudetoatefinal.Converters.Converters;
import com.example.aplicatiecudetoatefinal.Data.BiletBD;
import com.example.aplicatiecudetoatefinal.Data.BiletDao;
import com.example.aplicatiecudetoatefinal.Data.BiletEntity;
import com.example.aplicatiecudetoatefinal.Utils.TipBilet;

import java.util.List;

public class Raport extends AppCompatActivity {

    private LinearLayout layout;
    private double[] values;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_raport);
        layout=findViewById(R.id.ll_layout);
        BiletBD biletBD=BiletBD.getDatabase(getApplicationContext());
        values=new double[TipBilet.values().length];
        final BiletDao biletDao=biletBD.biletDao();
        final List<BiletEntity> biletEntityList=biletDao.getAllBilete();
        for(BiletEntity bilet: biletEntityList) {
            Log.v("BdBilet",bilet.toString());
            int index;
            switch (new Converters().StringToEnum(bilet.getTipBilet())) {
                case "normal":
                    index=0;
                    break;
                case "extra":
                    index=1;
                    break;
                case "vip":
                    index=2;
                    break;
                default:
                    throw new IllegalStateException("Unexpected value: " + new Converters().StringToEnum(bilet.getTipBilet()));
            }
            values[index]++;
        }
        layout.addView(new PieChartView(this,calculatePieChartData(values)));

    }

    private double[] calculatePieChartData(double [] values){
        float total = 0;
        double[] pieValues = new double[values.length];
        for(int i=0; i<values.length; i++) {
            total+= values[i];
        }
        for(int i = 0; i<values.length; i++) {
            pieValues[i] = 360 * (values[i] / total);
        }
        return pieValues;
    }

    public class PieChartView extends View {

        private double[] valuesDegreed;
        private Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private int[] COLORS = {Color.BLUE, Color.GREEN,Color.YELLOW, Color.RED,Color.MAGENTA,Color.CYAN};
        private RectF rectangle = new RectF(10, 10, 500, 500);
        private String[] labels={"normal","extra","vip"};
        private int tmp = 0;

        public PieChartView(Context context, double[] values) {
            super(context);
            valuesDegreed = new double[values.length];
            for (int i = 0; i < values.length; i++) {
                valuesDegreed[i] = values[i];
            }
        }

        @Override
        protected void onDraw(Canvas canvas) {
            super.onDraw(canvas);
            for(int i=0;i<valuesDegreed.length;i++) {
                paint.setColor(COLORS[i]);
                paint.setTextSize(30);
                String text=labels[i];
                int x=600;
                int y=50+(i*50);
                canvas.drawText(text,x,y,paint);
            }
            for (int i = 0; i < valuesDegreed.length; i++) {
                paint.setColor(COLORS[i]);
                if (i == 0) {
                    canvas.drawArc(rectangle, 0, (float) valuesDegreed[i], true, paint);
                    paint.setColor(Color.BLACK);
                    paint.setTextSize(30);
                    canvas.drawText("titlu", 10, 10, paint);
                } else {
                    tmp += (int) valuesDegreed[i - 1];
                    canvas.drawArc(rectangle, tmp, (float) valuesDegreed[i], true, paint);
                }
            }
        }
    }
}