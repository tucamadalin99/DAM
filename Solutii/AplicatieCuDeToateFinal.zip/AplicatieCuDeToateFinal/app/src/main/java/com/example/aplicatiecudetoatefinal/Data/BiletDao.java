package com.example.aplicatiecudetoatefinal.Data;

import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.Query;
import androidx.room.Update;

import java.util.List;

@Dao
public interface BiletDao {

    @Insert
    void addBilet(BiletEntity biletEntity);

    @Query("SELECT * FROM bilete")
    List<BiletEntity> getAllBilete();

    @Update
    void updateBilet(BiletEntity biletEntity);

    @Query("DELETE FROM bilete WHERE nume=(:nume)")
    void deleteBilet(String nume);


}
